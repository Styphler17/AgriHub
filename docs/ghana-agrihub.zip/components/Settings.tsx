
import React, { useState } from 'react';
import { User, Language } from '../types';
import { 
  User as UserIcon, 
  Globe, 
  Moon, 
  Database, 
  Save, 
  MapPin, 
  Briefcase,
  Check,
  Smartphone
} from 'lucide-react';

interface Props {
  user: User;
  setUser: (user: User) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  lowDataMode: boolean;
  setLowDataMode: (low: boolean) => void;
  t: any;
}

const SettingsView: React.FC<Props> = ({ 
  user, 
  setUser, 
  lang, 
  setLang, 
  darkMode, 
  setDarkMode, 
  lowDataMode,
  setLowDataMode,
  t 
}) => {
  const [name, setName] = useState(user.name);
  const [location, setLocation] = useState(user.location);
  const [role, setRole] = useState(user.role);
  const [isSaved, setIsSaved] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({ ...user, name, location, role });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-slide-in">
      {/* Profile Settings */}
      <section className={`p-8 rounded-3xl ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} border shadow-sm`}>
        <div className="flex items-center gap-3 mb-8">
          <div className="p-3 rounded-2xl bg-green-100 text-green-600">
            <UserIcon size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Profile Information</h2>
            <p className="text-slate-500 text-sm">Update your account details and role</p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase">Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border outline-none transition-all ${
                    darkMode ? 'bg-slate-900 border-slate-700 focus:border-green-600' : 'bg-slate-50 border-slate-200 focus:border-green-600'
                  }`}
                  placeholder="Your Name"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase">Location</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border outline-none transition-all ${
                    darkMode ? 'bg-slate-900 border-slate-700 focus:border-green-600' : 'bg-slate-50 border-slate-200 focus:border-green-600'
                  }`}
                  placeholder="e.g. Kumasi, Ashanti"
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-slate-400 uppercase">Role</label>
              <div className="relative">
                <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className={`w-full pl-12 pr-4 py-3 rounded-xl border outline-none transition-all appearance-none ${
                    darkMode ? 'bg-slate-900 border-slate-700 focus:border-green-600' : 'bg-slate-50 border-slate-200 focus:border-green-600'
                  }`}
                >
                  <option value="farmer">Farmer</option>
                  <option value="buyer">Buyer</option>
                  <option value="extension-officer">Extension Officer</option>
                </select>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3 rounded-xl shadow-lg transition-all"
          >
            {isSaved ? <Check size={20} /> : <Save size={20} />}
            {isSaved ? 'Saved!' : 'Save Profile'}
          </button>
        </form>
      </section>

      {/* Preferences Settings */}
      <section className={`p-8 rounded-3xl ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} border shadow-sm`}>
        <div className="flex items-center gap-3 mb-8">
          <div className="p-3 rounded-2xl bg-blue-100 text-blue-600">
            <Globe size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold">App Preferences</h2>
            <p className="text-slate-500 text-sm">Customize language and data usage</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Language Toggle */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center gap-4">
              <Globe size={20} className="text-slate-400" />
              <div>
                <div className="font-bold">App Language</div>
                <div className="text-xs text-slate-500">Choose between English and Twi</div>
              </div>
            </div>
            <div className="flex bg-slate-200 dark:bg-slate-700 p-1 rounded-xl">
              <button
                onClick={() => setLang('en')}
                className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  lang === 'en' ? 'bg-white dark:bg-slate-600 text-green-600 shadow-sm' : 'text-slate-500'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLang('tw')}
                className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  lang === 'tw' ? 'bg-white dark:bg-slate-600 text-green-600 shadow-sm' : 'text-slate-500'
                }`}
              >
                TW
              </button>
            </div>
          </div>

          {/* Dark Mode Toggle */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center gap-4">
              <Moon size={20} className="text-slate-400" />
              <div>
                <div className="font-bold">Dark Mode</div>
                <div className="text-xs text-slate-500">Reduce eye strain at night</div>
              </div>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`w-12 h-6 rounded-full transition-all relative ${
                darkMode ? 'bg-green-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${
                darkMode ? 'right-1' : 'left-1'
              }`} />
            </button>
          </div>

          {/* Low Data Mode Toggle */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center gap-4">
              <Database size={20} className="text-slate-400" />
              <div>
                <div className="font-bold">Low Data Mode</div>
                <div className="text-xs text-slate-500">Optimize for slower connections</div>
              </div>
            </div>
            <button
              onClick={() => setLowDataMode(!lowDataMode)}
              className={`w-12 h-6 rounded-full transition-all relative ${
                lowDataMode ? 'bg-green-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${
                lowDataMode ? 'right-1' : 'left-1'
              }`} />
            </button>
          </div>

          {/* SMS Integration Info */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800 flex items-start gap-4">
            <Smartphone size={20} className="text-amber-600 shrink-0 mt-1" />
            <div>
              <div className="font-bold text-amber-900 dark:text-amber-200 text-sm">SMS Offline Mode</div>
              <p className="text-xs text-amber-700 dark:text-amber-400 leading-relaxed">
                When you're completely offline, you can dial <span className="font-bold font-mono">*789#</span> to receive critical updates via SMS. This is part of our commitment to local farmers with limited internet access.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* App Version Info */}
      <div className="text-center py-6">
        <p className="text-xs text-slate-400 font-medium">Ghana AgriHub v1.0.4 - Production Release</p>
        <p className="text-[10px] text-slate-400 mt-1">Made with ❤️ for Ghanaian Smallholder Farmers</p>
      </div>
    </div>
  );
};

export default SettingsView;
