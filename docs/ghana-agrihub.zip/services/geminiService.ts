
import { GoogleGenAI } from "@google/genai";

export const getCropAdvice = async (crop: string, soil: string, region: string, language: 'en' | 'tw') => {
  // Always initialize GoogleGenAI with a named parameter and direct process.env.API_KEY access
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Provide detailed agricultural advice for a smallholder farmer in Ghana growing ${crop} in ${soil} soil in the ${region} region. 
  Include planting tips, common pests/diseases in Ghana, and organic prevention methods. 
  Answer in ${language === 'tw' ? 'Twi' : 'English'}. 
  Format as a structured guide.`;

  try {
    // Calling generateContent with the model name and prompt directly
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        temperature: 0.7,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    // Use .text property to extract output string
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not retrieve AI advice at this moment. Please check your connection or try again later.";
  }
};
