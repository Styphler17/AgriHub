
import { WeatherData } from '../types';
import { db } from '../db';

const MOCK_WEATHER: WeatherData = {
  city: "Kumasi",
  temp: 29,
  condition: "Partly Cloudy",
  icon: "cloud",
  forecast: [
    { day: "Mon", temp: 30, condition: "Sunny" },
    { day: "Tue", temp: 28, condition: "Rain" },
    { day: "Wed", temp: 27, condition: "Storms" },
    { day: "Thu", temp: 29, condition: "Partly Cloudy" },
    { day: "Fri", temp: 31, condition: "Sunny" },
    { day: "Sat", temp: 30, condition: "Clear" },
    { day: "Sun", temp: 28, condition: "Showers" },
  ]
};

export const fetchWeather = async (city: string): Promise<WeatherData> => {
  try {
    // In a real app: fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city},GH&appid=...`)
    // For now, return mock but simulate network
    await new Promise(r => setTimeout(r, 800));
    
    // Cache the result
    await db.weather.put(MOCK_WEATHER);
    return MOCK_WEATHER;
  } catch (error) {
    const cached = await db.weather.get(city);
    if (cached) return cached;
    throw error;
  }
};
